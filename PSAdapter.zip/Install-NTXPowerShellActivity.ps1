﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

Add-SPSolution -LiteralPath "$(Get-Location)\PSAdapter.wsp"
Install-SPSolution PSAdapter.wsp -GACDeployment

[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint")
[void][System.Reflection.Assembly]::LoadWithPartialName("Nintex.Workflow")
[void][System.Reflection.Assembly]::LoadWithPartialName("Nintex.Workflow.Administration")
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Xml.XmlDocument")


function Get-NtxPowerShellNwa(){

return "<NintexWorkflowActivity>
	<Name>PowerShell</Name>
	<Category>Operations</Category>
	<Description>Run PowerShell Script</Description>
	<ActivityType>PSActivity.Activity</ActivityType>
	<ActivityAssembly>PSActivity, Version=1.0.0.0, Culture=neutral, PublicKeyToken=8c2fe5a48e756d57</ActivityAssembly>
	<AdapterType>PSAdapter.Adapter</AdapterType>
	<AdapterAssembly>PSAdapter, Version=1.0.0.0, Culture=neutral, PublicKeyToken=8c2fe5a48e756d57</AdapterAssembly>
	<HandlerUrl>ActivityServer.ashx</HandlerUrl>
	<Icon>/_layouts/NintexWorkflow/CustomActions/PSAdapter/Images/NTX_PS_Large.png</Icon>
	<ToolboxIcon>/_layouts/NintexWorkflow/CustomActions/PSAdapter/Images/NTX_PS_Small.png</ToolboxIcon>
	<ConfigurationDialogUrl>CustomActions/PSAdapter/PSAdapterDialog.aspx</ConfigurationDialogUrl>
	<ShowInCommonActions>yes</ShowInCommonActions>
	<DocumentLibrariesOnly>no</DocumentLibrariesOnly>
</NintexWorkflowActivity>"
}

function Add-WebConfigEntries(){

$assemblyName = "PSActivity, Version=1.0.0.0, Culture=neutral, PublicKeyToken=8c2fe5a48e756d57"
$namespaceName = "PSActivity"
$typeName = "Activity"

foreach($spWebApplication in Get-SPWebApplication){

[Void][Nintex.Workflow.Administration.AuthorisedTypes]::InstallAuthorizedWorkflowTypes($spWebApplication, $assemblyName, $namespaceName, $typeName)

}

}

$nwaXml = New-Object -TypeName System.Xml.XmlDocument

$nwaXml.LoadXml($(Get-NtxPowerShellNwa))

$activityReference = [Nintex.Workflow.ActivityReference]::ReadFromNWA($nwaXml)

[Void][Nintex.Workflow.ActivityReferenceCollection]::AddActivity($activityReference.Name, $activityReference.Description, $activityReference.Category, $activityReference.ActivityAssembly, $activityReference.ActivityType, $activityReference.AdapterAssembly, $activityReference.AdapterType, $activityReference.HandlerUrl, $activityReference.ConfigPage, $activityReference.RenderBehaviour, $activityReference.Icon, $activityReference.ToolboxIcon, $activityReference.WarningIcon, $activityReference.QuickAccess, $activityReference.ListTypeFilter, @(), [int]"1033")
[Void][Nintex.Workflow.ActivityReferenceCollection]::RefreshActivityCache()

$installedActivityReference = [Nintex.Workflow.ActivityReferenceCollection]::FindByAdapter($activityReference.AdapterType, $activityReference.AdapterAssembly)

$activationReference = New-Object Nintex.Workflow.ActivityActivationReference -ArgumentList @(,$installedActivityReference.ActivityId, [Guid]::Empty, [Guid]::Empty)

$activationReference.AddOrUpdateActivationReference()

Add-WebConfigEntries;
